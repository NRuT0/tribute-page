# tribute
appu remains etched in our hearts forever.as a tribute to the power star Puneet Rajkumar, created this app for give him tribute

# If you like it please star the repository i took help of one of my friend repo to design this
Website - [Puneet-Rajkumar Tribute]( https://bit.ly/3D4Y95p)

Using HTML5 And CSS3,Bootstrap Materials,javascript Designed Tribute animation design TEMPLATE.



This is a personal website that I made for Great Soul,simple human being,smily face

Please If You Like My work Give ⭐⭐⭐⭐

Made with ❤️ using

- Flask framework
- Animate properties
- HTML,CSS
- JavaScript
- help of architics
- code pen
- json viewer
